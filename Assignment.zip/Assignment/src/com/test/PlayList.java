package com.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

public class PlayList {

public static void main(String[] args) {

List<String> playList = new ArrayList<String>();
playList.add("firstsong");
playList.add("secondsong");
playList.add("thirdsong");
//fourth song --------- 100th song
playList.add("100thsong");

for(int i=0;i<playList.size();++i){
 Random rand = new Random();
 
 int temp = rand.nextInt(playList.size() - i)+i;
 
 Collections.swap(playList,i,temp);
}
}
}
